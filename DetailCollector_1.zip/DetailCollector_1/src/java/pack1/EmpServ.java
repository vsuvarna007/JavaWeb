/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pack1;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author oltuser12
 */
@WebServlet(name = "EmpServ", urlPatterns = {"/EmpServ"})
public class EmpServ extends HttpServlet 
{
    @Override
    public void doGet(HttpServletRequest req, HttpServletResponse res) throws IOException, ServletException
    {
        res.setContentType("text/html");
        PrintWriter out = res.getWriter();
        String name = null ,citizen = null, addr = null;
        int age =0,phone=0,salary=0;
        try
        {
            name = req.getParameter("name");
            age = Integer.parseInt(req.getParameter("age"));
            addr = req.getParameter("addr");
            phone = Integer.parseInt(req.getParameter("phone"));
            salary = Integer.parseInt(req.getParameter("salary"));
            citizen = req.getParameter("citizen");
        }
        catch(Exception e)
        {
            out.println("Some Exception");
        }
        if(name.isEmpty()||addr.isEmpty()||citizen.isEmpty())
        {
            RequestDispatcher rd = req.getRequestDispatcher("index.html");
            out.println("Please enter all details");
            rd.include(req, res);
        }
        else
        {
            out.println("Employee Name is "+name);
            if(age>30)
            {
                salary+=5000;
                out.println("Added 5000, New Salary =  "+salary);
            }
            if(salary>50000)
            {
                int tax = (10/100)*salary;
                salary-=tax;
                out.println("Deducted 10%, New Salary = "+salary);
            }
            if(citizen.equalsIgnoreCase("Indian"))
            {
                salary+=2000;
                out.println("Added 2000, New Salary =  "+salary);
            }
        }
    
    }
}